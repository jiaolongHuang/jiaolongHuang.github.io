var spdy = require('./');
var fs = require('fs');
var url = require('url');

var options = {
  key: "-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEAwR9WNkAleV/CNFOZMRzWAcuq/BilL0KJdYbsdJXLbZ10pyJH\nw3J9TSlz/5mzrRArO7OrVl5XKFs6AXEIE4z7EN+MXzghFLO2+bu/HN/UtpD0dfiP\nX3OgqyAtLwiqwXnjis4jY0bzWKSc/4o17wFFKj+6Hvg/MKQBfrNmjHvKh1Zrr2ba\nA76z8ZrHIRiiD/ueT2eScRppF+WsJ402zSO+KMqWFgucQPTj4w52KKVw7KdxrH5T\nTlpMImqVFyUhZ9lahbckVdfLiwToUkxZa2GdRBOLkvn0yNaMfFWogWkDjPiFNkL+\n91FudT8x1augPCuoOotbDhdDiUzaNo/feRw+LQIDAQABAoIBABoXN7iAlg99xmj3\nWlzuPmNjtqf0VGy8GoIMRmnBywf2G8pwsS1QjGkeTpObmlCpPI4GSgGTIUdMe9ux\n/5tUkp7G9NnwZVe8p925Zapq+vvnPX+qowQMRQqZgEE4dIlLBFi+XL2O2lWBd8x2\nSa8Oht+cWHLSqwbRQXpylkood0YtRFw91w1pgz376pU/GdUIPon3akmdk9VIsRe7\nNDRY00ZfP7paf9Xv0tvqgdrK4rfgoKN4V1BVzEOzC2LnThcN3yPw7YJDh27FJh5K\ngsi9FOLd4Vy2NOEqSkOM2CXv1x/59TSDsSmAjhQ2S8VtoIzFbUCVZ9S9cE64+wij\nJzi5ROkCgYEAyHm7mdIMHFC8En3uPm8/oLyEkO5BhUSVX0MDQy3zE2Emwg3zbOsZ\nWbpHTtGEkBwRZw7C+R3RxBPZCv4jYi1wIcpKdlUWonypVE3FQMjT27gTEEB4vFPO\na82hzXGPd+nYR9mJDFpn4gD1JksJXdqQ5MjAtMAaIFE9a3Jb+D21/d8CgYEA9pw/\nih5d+Pc63YuU0UOSqBlzkORnvQ50mtTNJgCKe7tdkMpUJWBkVdVaGUA1Ibt/iCfa\nJsMI49fEviS5yBC4CL28UsZ+Jc8i0wHoRbQx4TzQiVtsLu8SFyVGDQ9Fl+beKsk9\n3EHXztFDoHQ24BBbuzuWtYJJF4iEp63gSh6lLXMCgYAtguVB8FtrejCYChqx9dN+\nDA4UUOJy/LTkYXQ2JhJOzflciIpAqcahhhZ2ID518MlKmiFNKKXcW50kT7l8qlAQ\ne7oXzw1Kaf6O8vDa2jyuXsWFJP3D00rDUnVvDF7DnETLWukv8r4uooUE4ngH5HyM\nU77bydikiYzl/Zo/atMMBQKBgQClDn8Ymqqa8B5eGgZI6clG6YIIAFfOmdZBqxyD\nyujlV8qQFluriJCfQmVDcU4efbgmEUZZm0Bf/xKXkU0nMsl6UEOzw1a7R6AvSp+D\nx896yZFp3d7SqwCYrUHti8MwoD0itf7JZOhkbHuu8Rmpbkl3T7LXWZRCRAVFlYMB\nGPHFMQKBgD+hkh+kW650LXBQACY0ICY7AhDzPeBKBTTAcLUe0Ct4hIY3xdNI3WnP\nvgz2SkoTWddN/BBXp/qO1p6LYTR4mNtC4txAkh3GVI52T7uo9FAWowtIti/WkT4T\nraQoZYveKMA+jzFu8V37xdK3LO1Ywf1ORnmeTSMGvbcrozRASbOc\n-----END RSA PRIVATE KEY-----",
  cert: "-----BEGIN CERTIFICATE-----\nMIICvzCCAamgAwIBAgIDAQABMAsGCSqGSIb3DQEBCzAWMRQwEgYDVQQDFgtpbmR1\ndG55LmNvbTAeFw02OTAxMDEwMDAwMDBaFw0yNTA3MjQyMTIzMzRaMBYxFDASBgNV\nBAMWC2luZHV0bnkuY29tMIIBIDALBgkqhkiG9w0BAQEDggEPADCCAQoCggEBAMEf\nVjZAJXlfwjRTmTEc1gHLqvwYpS9CiXWG7HSVy22ddKciR8NyfU0pc/+Zs60QKzuz\nq1ZeVyhbOgFxCBOM+xDfjF84IRSztvm7vxzf1LaQ9HX4j19zoKsgLS8IqsF544rO\nI2NG81iknP+KNe8BRSo/uh74PzCkAX6zZox7yodWa69m2gO+s/GaxyEYog/7nk9n\nknEaaRflrCeNNs0jvijKlhYLnED04+MOdiilcOyncax+U05aTCJqlRclIWfZWoW3\nJFXXy4sE6FJMWWthnUQTi5L59MjWjHxVqIFpA4z4hTZC/vdRbnU/MdWroDwrqDqL\nWw4XQ4lM2jaP33kcPi0CAwEAAaMcMBowGAYDVR0RBBEwD4INKi5pbmR1dG55LmNv\nbTALBgkqhkiG9w0BAQsDggEBAAqi508vuYV8UI9j7GgAwR1YY7c34yK0U7lRYKvJ\nliIfRMGsTV2R0mu8SfaM2bs2mt8qajEBqEVmwUf43mdgXdqWO8sVrLiRrCyI0FV4\n8V+Wafq0LARPleH0jIovP8Uc8WjJISK7UxnmaG4J7i1e4tSU6vVgR6VLVtY0lD0X\ndh04xrZm5CCY9LgUB/sMBYrFds+8nZidkes1E70bIlaxvxRAZyN3k3KOZh29FXXi\nKOVzRLwcZ6GIw1wA5UIkwmjdb6eOR5VjHKAiXVLMB8q1ZQMfaEI9UhCxVW/ZGro/\n5qQORcR6C1ILwgjpgswbJ0cwqBw5ve2KuJvKjzPBPC7g5zc=\n-----END CERTIFICATE-----",
  ALPNProtocols: [ 'spdy/3.1' ],
  NPNProtocols: [ 'spdy/3.1' ]
};

function start( route, handle ){
	function onRequest(request, response) {
	    var pathname = url.parse(request.url).pathname;
	    console.log("Request for " + pathname + " received.");
	    
	    route(handle, pathname, response, request); //传参
	  }
	spdy.createServer( options, onRequest ).listen(1443);
}

exports.start = start;