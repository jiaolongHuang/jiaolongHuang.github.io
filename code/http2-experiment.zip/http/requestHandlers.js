var querystring = require('querystring');
var fs = require('fs'); //将文件读取到服务器中

function start( response, request ){
	var body = '<!DOCTYPE html>'+
	'<html lang="en">'+
	'<head>'+
		'<meta charset="UTF-8">'+
		'<title>http</title>'+
	'</head>'+
	'<body>'+

		'<img src="./resource/11.jpg?t=1" width="200px" height="150px"/>'+
		
		'<link rel="stylesheet" href="./resource/1.css">'+
		'<script src="./resource/1.js"></script>'+
		'<img src="./resource/11.jpg?t=2" width="200px" height="150px"/>'+
		'<img src="./resource/11.jpg?t=3" width="200px" height="150px"/>'+
		'<img src="./resource/11.jpg?t=4" width="200px" height="150px"/>'+
		'<img src="./resource/11.jpg?t=5" width="200px" height="150px"/>'+
		'<img src="./resource/11.jpg?t=6" width="200px" height="150px"/>'+
		'<img src="./resource/11.jpg?t=7" width="200px" height="150px"/>'+
		'<img src="./resource/11.jpg?t=8" width="200px" height="150px"/>'+
		'<img src="./resource/11.jpg?t=9" width="200px" height="150px"/>'+
		'<img src="./resource/11.jpg?t=10" width="200px" height="150px"/>'+
	'</body>'+
	'</html>';

	response.writeHead(200, {"Content-Type": "text/html"});
	response.write(body);
	response.end();
}
exports.start = start;