/*var http2 = require('http2');
var fs = require('fs');
var url = require('url');

var options = {
  key: fs.readFileSync('./example/localhost.key'),
  cert: fs.readFileSync('./example/localhost.crt')
};

function start( route, handle ){
	function onRequest(request, response) {
	    var pathname = url.parse(request.url).pathname;
	    console.log("Request for " + pathname + " received.");
	    
	    route(handle, pathname, response, request); //传参
	  }
	http2.createServer( options, onRequest ).listen(8080);
}*/
var http = require('http'); //http 服务器的核心嘛
var url = require('url'); //url 解析路径
	
function start(route, handle){
	http.createServer(function(request, response){
		var pathname = url.parse(request.url).pathname; //解析路径
		console.log('Request for ' + pathname + ' received.');
		route(handle, pathname, response, request); //传参
	}).listen(8888); //监听端口8888
	console.log('Server has started\nhttp://localhost:8888/');
}

/*var https = require('https');
var fs = require('fs');
var url = require('url');

var options = {
  key: fs.readFileSync('./example/localhost.key'),
  cert: fs.readFileSync('./example/localhost.crt')
};

function start( route, handle ){
	function onRequest(request, response) {
	    var pathname = url.parse(request.url).pathname;
	    console.log("Request for " + pathname + " received.");
	    
	    route(handle, pathname, response, request); //传参
	  }
	https.createServer( options, onRequest ).listen(8080);
}*/

exports.start = start;