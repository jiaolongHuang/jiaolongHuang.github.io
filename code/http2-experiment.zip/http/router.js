var fs = require('fs');

function route(handle, pathname, response, request){
	console.log('About to route a request for ' + pathname);
	if(typeof handle[pathname] === 'function'){
		return handle[pathname](response, request);
	} else if(pathname.indexOf("/resource/") == 0){

		fs.readFile( './' + pathname , 'binary', function(err, file){
			if(err){
				response.writeHead(500, {"Content-Type": "text/plain"});
				response.write(err+'\n');
				response.end();
			}else{
				response.writeHead(200);
				response.write(file, 'binary');
				response.end();
			}
		});

	} else{
		console.log("No request handler found for " + pathname);
		response.writeHead(404, {"Content-type":"text/plain"});
		response.write('404 Not Found');
		response.end();
	}
}
	
exports.route = route;