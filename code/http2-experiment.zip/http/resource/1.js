(function () {
	console.log('test');
})();